﻿#pragma once
#include "string"
#include "windows.h"
namespace Project2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Сводка для MyForm1
	/// </summary>
	public ref class MyForm1 : public System::Windows::Forms::Form
	{
	public:
		MyForm1(void)
		{
			InitializeComponent();
			//
			//TODO: добавьте код конструктора
			//

		}

	protected:
		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		~MyForm1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;

	private:

	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::Timer^ timer1;
	private: System::ComponentModel::IContainer^ components;
	protected:

	private:
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm1::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Black;
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button1->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.Image")));
			this->button1->Location = System::Drawing::Point(36, 941);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(175, 55);
			this->button1->TabIndex = 0;
			this->button1->Text = L"ДОМОЙ😈";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm1::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::Color::Indigo;
			this->textBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox1->ForeColor = System::Drawing::Color::White;
			this->textBox1->Location = System::Drawing::Point(439, 42);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox1->Size = System::Drawing::Size(1043, 407);
			this->textBox1->TabIndex = 1;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm1::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->BackColor = System::Drawing::Color::Indigo;
			this->textBox2->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox2->ForeColor = System::Drawing::Color::White;
			this->textBox2->Location = System::Drawing::Point(439, 491);
			this->textBox2->Multiline = true;
			this->textBox2->Name = L"textBox2";
			this->textBox2->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox2->Size = System::Drawing::Size(1043, 407);
			this->textBox2->TabIndex = 2;
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Black;
			this->button2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->button2->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button2->FlatAppearance->BorderSize = 0;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button2->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button2.Image")));
			this->button2->Location = System::Drawing::Point(506, 941);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(176, 55);
			this->button2->TabIndex = 3;
			this->button2->Text = L"ОЧИСТИТЬ ВСЁ";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm1::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::Black;
			this->button3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->FlatAppearance->BorderSize = 0;
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button3->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button3->ForeColor = System::Drawing::Color::White;
			this->button3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.Image")));
			this->button3->Location = System::Drawing::Point(1238, 941);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(176, 55);
			this->button3->TabIndex = 6;
			this->button3->Text = L"ОФОРМИТЬ";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm1::button3_Click_1);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::Black;
			this->button4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->button4->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button4->FlatAppearance->BorderSize = 0;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button4->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button4->ForeColor = System::Drawing::Color::White;
			this->button4->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button4.Image")));
			this->button4->Location = System::Drawing::Point(994, 941);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(176, 55);
			this->button4->TabIndex = 5;
			this->button4->Text = L"СТАРТ";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm1::button4_Click_1);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::Black;
			this->button6->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button6.BackgroundImage")));
			this->button6->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->button6->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button6->FlatAppearance->BorderSize = 0;
			this->button6->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button6->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button6->ForeColor = System::Drawing::Color::White;
			this->button6->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button6.Image")));
			this->button6->Location = System::Drawing::Point(750, 941);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(176, 55);
			this->button6->TabIndex = 4;
			this->button6->Text = L"ОЧИСТИТЬ";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm1::button6_Click);
			// 
			// textBox3
			// 
			this->textBox3->BackColor = System::Drawing::Color::Indigo;
			this->textBox3->Cursor = System::Windows::Forms::Cursors::Arrow;
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox3->ForeColor = System::Drawing::Color::White;
			this->textBox3->Location = System::Drawing::Point(766, 455);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(390, 30);
			this->textBox3->TabIndex = 7;
			this->textBox3->Text = L"Скорость сарделек: ";
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::Color::Indigo;
			this->comboBox1->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Pusia Bold", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->comboBox1->ForeColor = System::Drawing::Color::White;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(7) {
				L"Леопард", L"Всё о чтении", L"Приключения Тома Сойера",
					L"Робинзон Крузо", L"Чёрная курица или подземные жители", L"Медвежонок Джонни", L"Три товарища"
			});
			this->comboBox1->Location = System::Drawing::Point(1554, 230);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(294, 36);
			this->comboBox1->TabIndex = 8;
			this->comboBox1->Text = L"ВЫБЕРИТЕ ТЕКСТ";
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm1::comboBox1_SelectedIndexChanged);
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Interval = 200;
			this->timer1->Tick += gcnew System::EventHandler(this, &MyForm1::timer1_Tick);
			// 
			// MyForm1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(1904, 1041);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"MyForm1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Скоростные пальчики";
			this->Load += gcnew System::EventHandler(this, &MyForm1::MyForm1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		Close();
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		textBox1->Clear();
		textBox2->Clear();
	}
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
		textBox2->Clear();
	}
#include "string"
#include <string>
#include "windows.h"
#include <windows.h>


		   int k = 0;
	public: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	}
		  int l;
	public: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
		int l = textBox1->Text->Length;
		int s = sec;
		if (textBox1->Text == textBox2->Text) {
			textBox3->Text = "Скорость сарделек: " + System::Convert::ToString(l/s);
			textBox3->Text += " скуик/с";
		}
	}

	private: System::Void MyForm1_Load(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
		if (comboBox1->SelectedItem == "Леопард") {
			textBox1->Text = "Леопард является видом хищных млекопитающих семейства кошачьих. В древние времена существовало мнение о том, что леопард не что иное как гибрид пантеры и льва. Именно это предположение вылилось в название животного, соединив в себе два греческих слова: «леон» (что в переводе означает «лев») и «пардос» (что в переводе означает пантера). Леопард является кошкой больших размеров, но уступает своей величиной тигру и льву. Тело животного вытянутое и мускулистое. Длина хвоста леопарда превышает половину длины его тела. Ноги леопарда сильные, но короткие. Лапы широкие и массивные, а голова не отличается большими размерами и имеет округлую форму. У леопарда небольшие глаза с круглыми зрачками. Грива у леопарда отсутствует, вибриссы черные или белые достигают 110 мм в длину. Что касается массы тела леопарда и его размеров, то эти показатели связаны с его географической областью обитания. Животные, обитающие на территории лесов, обладают меньшими размерами и массой тела, чем их собратья, населяющие открытые участки земли. Мех у взрослого леопарда короткий и непышный (даже в зимний период), равномерно распределенный по всей длине его тела. Шерсть довольно густая и короткая. Черные и желтые волосы на теле леопарда имеют разную длину и толщину. Каждая особь леопарда имеет уникальное расположение пятен на теле. Эту особенность очень удобно использовать для идентификации конкретных особей животных. Такое качество можно сравнить с уникальностью отпечатков пальцев на руках человека. Исследователи часто пользуются такой особенностью леопардов, чтобы выявлять в условиях дикой природы отдельных особей вида, за которыми они ведут наблюдение. Сами леопарды используют такую уникальную особенность в качестве маскировки во время охоты. Черные пантеры, также известные как леопарды-меланисты, встречаются в Юго-Восточной Азии. Однако окрас шкуры пантеры не совсем черный — на ней всегда проступают пятна. Благодаря черному цвету меха, такие животные успешно маскируются в лесах. Чаще всего такие виды встречаются на острове Ява. Среди леопардов встречаются гибриды — такие как леопон. Леопон является гибридом, получившимся в результате скрещивания самца леопарда с самкой льва. Впервые существование леопона было официально подтверждено в Колхапуре в Индии в начале XX века. Внешний вид леопона также довольно интересен. Его голова имеет форму, более схожую с львиной. Все остальные части тела гибрида боле схожи с телом леопарда. Леопард является одиночным животным, ведущим преимущественно ночной образ жизни. Эти животные могут с легкостью приспособиться к любым условиям обитания. Они могут жить как в лесах и горах, так и в пустынях. Площади их индивидуального обитания могут разниться от 8 до более чем 400 км2 — все зависит от рельефа местности и наличия пищи для животного. Скромные размеры барса не мешают ему успешно охотиться на крупную добычу — их жертвы иногда могут весить до 900 килограммов.";
		}
		if (comboBox1->SelectedItem == "Всё о чтении") {
			textBox1->Text = "Мысленно вернитесь в свое детство, когда вас учили читать. Сначала вы выучили алфавит и то, как буквы складываются в слоги. Затем – как из слогов получаются слова. И вот вы за партой и читаете вслух. При чтении вслух вас учили выговаривать слово за словом. Эта привычка, скорее всего, перешла и в чтение про себя. Если, читая про себя, вы все время проговариваете слова, значит, вы читаете не быстрее, чем говорите, примерно 150 слов в минуту. Складывание букв в слоги, а потом слогов в слова логически подводит к следующему шагу – формированию из слов фраз или смысловых единиц. Слова – это символы коммуникации, которые полностью передают смысл, только будучи связанными друг с другом. Поскольку вы учились читать, когда были ребенком, то, скорее всего, и сейчас стараетесь преуспеть в своем «взрослом» чтении с помощью устаревших методов давно прошедших школьных дней. Психологи считают, что наши важнейшие навыки формируются еще в детстве, а чтение – один из них. Неудивительно, что большинство из нас не справляются с современными потоками информации. Неэффективные навыки характеризуются в основном пассивным поведением,а эффективные требуют активного поведения. Приобретая навык скорочтения, вы станете больше читать за меньшее время, лучше сосредотачиваться, а также лучше понимать и запоминать информацию. Когда вы читаете, ваши глаза работают как фотоаппарат. Вы фотографируете слова и отправляете снимок в мозг, а он мгновенно интерпретирует смысл слов. В действительности, пока вы читаете эти строки, ваши глаза постоянно останавливаются – это около 95% времени, потраченного на чтение. Ваш взгляд не переходит непрерывно от слова к слову, а все время задерживается и вновь начинает движение. Позже, когда вы научите свои глаза делать цельный, или панорамный фотоснимок, вашему взгляду не придется так часто останавливаться, и он будет схватывать больше. Картинки большего размера означают большее количество слов, отправленных в ваш мозг на каждой остановке, и в результате он получает возможность понимать фразы и предложения. Как только вы научитесь чувствовать ритм чтения, вы сможете читать дольше, не уставая, и получать гораздо больше информации за минуту. Просмотр статей, сайтов, форумов, вывесок, чтение блогов, книг, заголовков стало для нас ежедневной практикой. Кто владеет информацией, тот владеет миром. Улучшив свои читательские способности, вы обнаружите, что приобрели множество полезных качеств – стали интересным собеседником или более квалифицированным работником, улучшили скорость обучения, запоминания и поиска информации, начали меньше уставать, а успевать больше. Скорочтение - это не только про книги. Это про вашу личную эффективность.";
		}
		if (comboBox1->SelectedItem == "Приключения Тома Сойера") {
			textBox1->Text = "Том выпустил кисть из рук с виду не очень охотно, зато с ликованием в душе. И пока бывший пароход «Большая Миссури» трудился в поте лица на солнцепеке, удалившийся от дел художник, сидя в тени на бочонке, болтал ногами, жевал яблоко и обдумывал дальнейший план избиения младенцев. За ними дело не стало. Мальчики ежеминутно пробегали по улице; они подходили, чтобы посмеяться над Томом, – и оставались белить забор. Когда Бен выдохся, Том продал следующую очередь Билли Фишеру за подержанного бумажного змея, а когда тот устал белить, Джонни Миллер купил очередь за дохлую крысу с веревочкой, чтобы удобней было вертеть, и т.д. и т.д., час за часом. К середине дня из бедного мальчика, близкого к нищете, Том стал богачом и буквально утопал в роскоши. Кроме уже перечисленных богатств, у него имелось: двенадцать шариков, сломанная губная гармоника, осколок синего бутылочного стекла, чтобы глядеть сквозь него, пустая катушка, ключ, который ничего не отпирал, кусок мела, хрустальная пробка от графина, оловянный солдатик, пара головастиков, шесть хлопушек, одноглазый котенок, медная дверная ручка, собачий ошейник без собаки, черенок от ножа, четыре куска апельсинной корки и старая оконная рама. Том отлично провел все это время, ничего не делая и веселясь, а забор был покрыт известкой в три слоя! Если б у него не кончилась известка, он разорил бы всех мальчишек в городе. Том подумал, что жить на свете не так уж плохо. Сам того не подозревая, он открыл великий закон, управляющий человеческими действиями, а именно: для того чтобы мальчику или взрослому захотелось чего-нибудь, нужно только одно – чтобы этого было нелегко добиться. Если бы Том был великим и мудрым мыслителем, вроде автора этой книги, он сделал бы вывод, что Работа – это то, что человек обязан делать, а Игра – то, чего он делать не обязан. И это помогло бы ему понять, почему делать искусственные цветы или носить воду в решете есть работа, а сбивать кегли или восходить на Монблан – забава. Есть в Англии такие богачи, которым нравится в летнюю пору править почтовой каретой, запряженной четвериком, потому что это стоит им бешеных денег; а если б они получали за это жалованье, игра превратилась бы в работу и потеряла для них всякий интерес. Том раздумывал еще некоторое время над той существенной переменой, какая произошла в его обстоятельствах, а потом отправился с донесением в главный штаб.";
		}
		if (comboBox1->SelectedItem == "Робинзон Крузо") {
			textBox1->Text = "Много раз пытался я сплести себе корзину, но те прутья, которые мне удавалось достать, оказывались такими ломкими, что у меня ничего не выходило. Ребенком я очень любил ходить к одному корзинщику, проживавшему в нашем городе, и смотреть, как он работает. И теперь это мне пригодилось. Все дети наблюдательны и любят помогать взрослым. Приглядевшись к работе корзинщика, я скоро подметил, как плетутся корзины, и по мере сил помогал моему приятелю работать. Понемногу я научился плести корзины не хуже его. Так что теперь мне не хватало только материала. Наконец мне пришло в голову: не подойдут ли для этого дела ветки тех деревьев, из которых я сделал частокол? Ведь у них должны быть упругие, гибкие ветки, как у нашей вербы или ивы. И я решил попробовать. На другой же день я отправился на дачу, срезал несколько веток, выбирая самые тонкие, и убедился, что они как нельзя лучше годятся для плетения корзин. В следующий раз я пришел с топором, чтобы сразу нарубить побольше веток. Мне не пришлось долго разыскивать их, так как деревья этой породы росли здесь в большом количестве. Нарубленные прутья я перетащил за ограду моего шалаша и спрятал. Как только начался период дождей, я сел за работу и сплел очень много корзин. Они служили мне для разных надобностей: я носил в них землю, складывал всякие вещи и т.д. Правда, корзины выходили у меня грубоватые, я не мог придать им изящества, но, во всяком случае, они хорошо выполняли свое назначение, а мне только это и нужно было. С тех пор мне часто приходилось заниматься плетением корзин: старые ломались или изнашивались и нужны были новые. Я делал всякие корзины – и большие и маленькие, но главным образом запасался глубокими и прочными корзинами для хранения зерна: я хотел, чтобы они служили мне вместо мешков. Правда, сейчас зерна у меня было мало, но ведь я намеревался копить его в течение нескольких лет... Я уже говорил, что мне очень хотелось обойти весь остров и что я несколько раз доходил до ручья и еще выше – до того места, где построил шалаш. Оттуда можно было свободно пройти к противоположному берегу, которого я еще никогда не видал. Я взял ружье, топорик, большой запас пороха, дроби и пуль, прихватил на всякий случай два сухаря и большую ветку изюма и пустился в путь. За мною, как всегда, побежала собака. Когда я дошел до моего шалаша, я, не останавливаясь, двинулся дальше, на запад. И вдруг, пройдя с полчаса, я увидел перед собою море, а в море, к моему удивлению, полосу земли. Был яркий, солнечный день, я хорошо различал землю, но не мог определить, материк это или остров. Высокое плоскогорье тянулось с запада на юг и находилось от моего острова очень далеко, – по моему расчету, милях в сорока, если не больше. Я не имел понятия, что это за земля. Одно я знал твердо: это, несомненно, часть Южной Америки, лежащая, по всей вероятности, недалеко от испанских владений. Весьма возможно, что там живут дикари-людоеды и что, если бы я попал туда, мое положение было бы еще хуже, чем теперь. Эта мысль доставила мне живейшую радость.";
		}
		if (comboBox1->SelectedItem == "Чёрная курица или подземные жители") {
			textBox1->Text = "В числе тридцати или сорока детей, обучавшихся в том пансионе, находился один мальчик, по имени Алеша, которому тогда было не более девяти или десяти лет. Родители его, жившие далеко-далеко от Петербурга, года за два перед тем привезли его в столицу, отдали в пансион и возвратились домой, заплатив учителю условленную плату за несколько лет вперед. Алеша был мальчик умненькой, миленькой, учился хорошо, и все его любили и ласкали; однако, несмотря на то, ему часто скучно бывало в пансионе, а иногда даже и грустно. Особливо сначала он никак не мог приучиться к мысли, что он разлучен с родными своими; но потом, мало-помалу, он стал привыкать к своему положению, и бывали даже минуты, когда, играя с товарищами, он думал, что в пансионе гораздо веселее, нежели в родительском доме. Вообще дни учения для него проходили скоро и приятно; но когда наставала суббота и все товарищи его спешили домой к родным, тогда Алеша горько чувствовал свое одиночество. По воскресеньям и праздникам он весь день оставался один, и тогда единственным утешением его было чтение книг, которые учитель позволял ему брать из небольшой своей библиотеки. Учитель был родом немец, а в то время в немецкой литературе господствовала мода на рыцарские романы и на волшебные повести, – и библиотека, которою пользовался наш Алеша, большею частию состояла из книг сего рода. Итак, Алеша, будучи еще в десятилетнем возрасте, знал уже наизусть деяния славнейших рыцарей, по крайней мере так, как они описаны были в романах. Любимое его занятие в длинные зимние вечера, по воскресеньям и другим праздничным дням, было мысленно переноситься в старинные, давно прошедшие веки… Особливо в вакантное время – как например об Рождестве или в Светлое Христово Воскресенье, – когда он бывал разлучен надолго со своими товарищами, когда часто целые дни просиживал в уединении, – юное воображение его бродило по рыцарским замкам, по страшным развалинам или по темным дремучим лесам.";
		}
		if (comboBox1->SelectedItem == "Медвежонок Джонни") {
			textBox1->Text = "Джонни был забавный маленький медвежонок, живший со своей матерью в Йеллоустонском парке. Мать его звали Грэмпи (Злюка). Вместе с другими медведями они жили в лесу возле гостиницы. По распоряжению управляющего гостиницей все отбросы из кухни сносили на открытую поляну в окрестном лесу, где медведи могли пировать ежедневно в течение всего лета. С тех пор как Йеллоустонский парк был объявлен заповедником для диких животных, где они пользовались полной неприкосновенностью, количество медведей там из года в год возрастало. Мирные шаги со стороны человека не остались без ответа, и многие из медведей настолько хорошо освоились с прислугой гостиницы, что даже получили прозвища, соответствующие их внешнему виду и поведению. Один очень длинноногий и худой черный медведь назывался Тощим Джимом. Другой черный медведь звался Снаффи (фыркающий); он был так черен, будто его закоптили. Фэтти (толстяк) был очень жирный, ленивый медведь, вечно занятый едой. Два лохматых подростка, которые всегда приходили и уходили вместе, назывались Близнецами. Но наибольшей известностью пользовались Грэмпи и маленький Джонни. Грэмпи была самой большой и свирепой из черных медведиц, а Джонни, ее единственный сын, был надоедлив и несносен, так как никогда не переставал ворчать и скулить. Вероятно, это объяснялось какой-нибудь болезнью, потому что ни один здоровый медвежонок, как и всякое здоровое дитя, не станет беспричинно скулить все время. В самом деле, Джонни был похож на больного. У него, по-видимому, постоянно болел живот, и это показалось мне вполне естественным, когда я увидел, какую ужасающую мешанину пожирал он на свалке. Он пробовал решительно все, что видел. А мать, вместо того чтобы запретить ему, смотрела на такое обжорство с полным равнодушием. У Джонни были только три здоровые лапы, блеклый скверный мех и несоразмерно большие уши и брюхо. Однако мать обожала его; она, по-видимому, была убеждена, что сын ее красавец, и, конечно, совсем избаловала его. Грэмпи была готова подвергаться каким угодно неприятностям ради него, а он всегда с удовольствием давал ей повод для беспокойства. Больной и хилый Джонни был далеко не дурак и умел заставлять свою мамашу делать все, что он захочет.";
		}
		if (comboBox1->SelectedItem == "Три товарища") {
			textBox1->Text = "На следующий день было воскресенье. Я спал долго и проснулся только, когда солнце осветило мою постель. Быстро вскочив, я распахнул окно. День был свеж и прозрачно ясен. Я поставил спиртовку на табурет и стал искать коробку с кофе. Моя хозяйка — фрау Залевски — разрешала мне варить кофе в комнате. Сама она варила слишком жидкий. Мне он не годился, особенно наутро после выпивки. Вот уже два года, как я жил в пансионе фрау Залевски. Мне нравилась улица. Здесь всегда что-нибудь происходило, потому что вблизи друг от друга расположились дом профсоюзов, кафе „Интернациональ“ и сборный пункт Армии спасения. К тому же, перед нашим домом находилось старое кладбище, на котором уже давно никого не хоронили. Там было много деревьев, как в парке, и в тихие ночи могло показаться, что живешь за городом. Но тишина наступала поздно, потому что рядом с кладбищем была шумная площадь с балаганами, каруселями и качелями. Для фрау Залевски соседство кладбища было на руку. Ссылаясь на хороший воздух и приятный вид, она требовала более высокую плату. Каждый раз она говорила одно и то же: «Вы только подумайте, господа, какое местоположение!» Одевался я медленно. Это позволяло мне ощутить воскресенье. Я умылся, побродил по комнате, прочел газету, заварил кофе и, стоя у окна, смотрел, как поливают улицу, слушал пение птиц на высоких кладбищенских деревьях. Казалось, это звуки маленьких серебряных флейт самого Господа Бога сопровождают нежное ворчанье меланхолических шарманок на карусельной площади… Я выбрал рубашку и носки, и выбирал так долго, словно у меня их было в двадцать раз больше, чем на самом деле. Насвистывая, я опорожнил свои карманы: монеты, перочинный нож, ключи, сигареты… вдруг вчерашняя записка с номером телефона и именем девушки. Патриция Хольман. Странное имя — Патриция. Я положил записку на стол. Неужели это было только вчера? Каким давним это теперь казалось, — почти забытым в жемчужно-сером чаду опьянения. Как странно всё-таки получается: когда пьешь, очень быстро сосредоточиваешься, но зато от вечера до утра возникают такие интервалы, которые длятся словно годы. Я сунул записку под стопку книг. Позвонить? Пожалуй… А пожалуй, не стоит. Ведь на следующий день всё выглядит совсем по-другому, не так, как представлялось накануне вечером. В конце концов я был вполне удовлетворен своим положением. Последние годы моей жизни были достаточно суматошливыми. „Только не принимать ничего близко к сердцу, — говорил Кестер. — Ведь то, что примешь, хочешь удержать. А удержать нельзя ничего“. В это мгновенье в соседней комнате начался обычный воскресный утренний скандал. Я искал шляпу, которую, видимо, забыл где-то накануне вечером, и поневоле некоторое время прислушивался. Там неистово нападали друг на друга супруги Хассе. Они уже пять лет жили здесь в маленькой комнате. Это были неплохие люди. Если бы у них была трехкомнатная квартира с кухней, в которой жена хозяйничала бы, да к тому же был бы еще и ребенок, их брак, вероятно, был бы счастливым. Но на квартиру нужны деньги. И кто может себе позволить иметь ребенка в такое беспокойное время. Вот они и теснились вдвоем; жена стала истеричной, а муж всё время жил в постоянном страхе. Он боялся потерять работу, для него это был бы конец. Хассе было сорок пять лет. Окажись он безработным, никто не дал бы ему нового места, а это означало беспросветную нужду. Раньше люди опускались постепенно, и всегда еще могла найтись возможность вновь подняться, теперь за каждым увольнением зияла пропасть вечной безработицы.";
		}
	}
		   float sec = 0;
	private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e) {
		sec = sec+0.2;
	}
	private: System::Void button3_Click_1(System::Object^ sender, System::EventArgs^ e) {
		int l = textBox1->Text->Length;
		if (textBox1->Text == textBox2->Text) {
			textBox3->Text = "Скорость сарделек: " + System::Convert::ToString(l/sec);
			textBox3->Text += " скуик/с";
		}
	};
	private: System::Void button4_Click_1(System::Object^ sender, System::EventArgs^ e) {
		sec = 0;
		}
	
};
	}
